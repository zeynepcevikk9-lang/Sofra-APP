import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const referencePath = existsSync(join(root, 'sofra-motoru-reference-v2.html'))
  ? join(root, 'sofra-motoru-reference-v2.html')
  : join(root, 'outputs', 'sofra-motoru-reference-v2.html');
const html = readFileSync(referencePath, 'utf8');

assert.match(html, /reference-v2-fit/, 'referans Fit ekranı eksik');
assert.match(html, /fit-profile-reference-v2/, 'referans Fit profil alanı eksik');
assert.match(html, /fit-v2-gender|Cinsiyet/, 'Fit cinsiyet alanı eksik');
assert.match(html, /data-fit-reference-goal="lose"/, 'kilo verme hedefi eksik');
assert.match(html, /data-fit-reference-goal="gain"/, 'kilo alma hedefi eksik');
assert.match(html, /Apple Health \/ Health Connect/, 'sağlık bağlantısı referansta eksik');
assert.match(html, /Bu prototipte gerçek HealthKit bağlantısı yok/, 'HealthKit demo sınırı görünür değil');
assert.match(html, /fit-recipe-reference-v2/, 'hedefe göre Fit tarif kartları eksik');
assert.match(html, /fit-reference-photo|images\.unsplash\.com/, 'Fit tariflerinde canlı görsel kancası eksik');
assert.doesNotMatch(html, /yaklaşık (?:320|390|410|520|540|620|680|760) kcal/, 'doğrulanmamış Fit tarif kalori iddiası var');
assert.match(html, /besin verisi bekleniyor/, 'Fit tarif besin verisi durumu açıkça belirtilmiyor');
assert.match(html, /dashboard\.querySelector\('\.fit-workout-v2'\)\?\.remove/, 'referans Fit ekranı antrenman bölümünü kaldırmıyor');
assert.match(html, /reference-family-v2/, 'Çocuğum için giriş kartı eksik');
assert.match(html, /mode-change.*setHomeModeV34\('sofra'\)/s, 'Fit ekranından Sofra’ya doğrudan dönüş eksik');
assert.doesNotMatch(html, /class="mode-change"[^>]+onclick="openWelcome\(\)"/, 'Fit ekranından çıkış gereksiz ilk giriş penceresini açıyor');
assert.match(html, /childRecipeData/, 'çocuk yaş grubu tarif verisi eksik');
for (const age of ['12–23 ay', '24–35 ay', '36+ ay']) assert.match(html, new RegExp(age.replace(/[+]/g, '\\+')), `çocuk yaş grubu eksik: ${age}`);
assert.match(html, /child-age-note-v2/, 'çocuk yaş filtresi açıklaması eksik');
assert.match(html, /photo-child-v2|childPhotoBase/, 'çocuk tariflerinde canlı görsel kancası eksik');
assert.match(html, /Zeytinyağlı patlıcan/, 'referans tarif kataloğunda patlıcan örneği eksik');
assert.match(html, /const recipeDetails=/, 'referans tarif detay verisi eksik');
assert.match(html, /<strong>Malzemeler<\/strong>/, 'referans tarif malzeme bölümü eksik');
assert.match(html, /<strong>Hazırlanış<\/strong>/, 'referans tarif hazırlanış bölümü eksik');

const scripts = [...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/gi)];
for (const [index, match] of scripts.entries()) {
  try { Function(match[1]); } catch (error) { throw new Error(`referans HTML script ${index + 1} parse edilemedi: ${error.message}`); }
}

console.log('SOFRA_REFERENCE_CONTRACT_TEST_OK');
console.log(`fitProfile=ok healthBoundary=ok realRecipePhotos=ok workoutSection=removed scripts=${scripts.length}`);
